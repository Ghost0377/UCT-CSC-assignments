# My very first program to display Hello World on screen
# Rector Ratsaka
# RTSREC001
# 18 February 2022

print("Hello World")