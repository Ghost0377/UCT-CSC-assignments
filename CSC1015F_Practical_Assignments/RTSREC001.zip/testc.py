#Rector Ratsaka

words = input("Enter a word (or 'DONE'):\n")
start = words[:1]
words_vow = 0
if start =='a' or start == 'e 'or start == 'i' or start =='o' or start =='u':
        words_vow = 1
    
while words != 'DONE':
        words = input("Enter a word (or 'DONE'):\n")        
        if words == 'DONE':
                print('Number of pairs of adjacent words starting with a vowel:',words_vow)
                break
    
    