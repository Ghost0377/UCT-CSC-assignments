//A programme 
//Rector Ratsaka
//RTSREC001
//03 August 2022

public class Seller {
    public String id;
   
    public String name;
    
    public String location;
    
    public String product;
    
    public String unitPrice;
   
    public int numUnits; 
}