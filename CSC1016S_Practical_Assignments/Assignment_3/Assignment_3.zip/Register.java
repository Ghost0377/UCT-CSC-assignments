//A programme 
//Rector Ratsaka
//RTSREC001
//13 August 2022

public class Register {
//instant variables
 public Ticket[] tickets;
 public int numTickets;
 //constructor
 public Register() {
  numTickets = 0;
  tickets = new Ticket[100];
 }
 //methods
 public void add(Ticket ticket) {
  tickets[numTickets] = ticket;
  numTickets++;
  
 }
 public boolean contains(String ticketID) {
  for (int i=0;i<tickets.length;i++) {
   if (tickets[i].ID().equals(ticketID)) {
    return true;
   }
   else {
    return false;
   }
  }
  return false;
 }

 public Ticket retrieve(String ticketID) {
   Ticket retrieved  = null;
      for (int i=0; i<tickets.length; i++)
      {
         if (tickets[i].ID().equals(ticketID))
         {
             retrieved = tickets[i];
             break;
         }
      }
      return retrieved;
     }
}