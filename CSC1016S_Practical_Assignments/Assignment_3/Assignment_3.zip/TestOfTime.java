//A programme 
//Rector Ratsaka
//RTSREC001
//13 August 2022

import org.junit.Assert;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;


public class TestOfTime {


   /** Fixture initialization (common initialization
    *  for all tests). **/
   @Before 
   public void setUp() {
   }


   /** A test that always fails. **/
   @Test 
   public void testTimeToString() {
     Time t1 = new Time("12:00");
     Time t2 = new Time("13:00");
     Assert.assertEquals("12:00:00",t1.toString());
     Assert.assertEquals(60,t2.subtract(t1));
     Assert.assertEquals(0,t1.subtract(t2));
   } 
   
   public void testDuration() { 
     Time t1 = new Time("12:00");
     Time t2 = new Time("13:00");
     Assert.assertEquals(3600000,t1.subtract(t2).intValue("millisecond"));
     Assert.assertEquals(3600,t1.subtract(t2).intValue("second"));
     Assert.assertEquals(60,t1.subtract(t2).intValue("minute"));
     Assert.assertEquals(1,t1.subtract(t2).intValue("hour"));
   }
   
  }
