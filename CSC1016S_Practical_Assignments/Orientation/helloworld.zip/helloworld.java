//My very first program to display hello world
//Name: Rector Ratsaka
//Student number: RTSREC001
//Date: 26 July 2022

class helloworld
{
  public static void main(String[] args)
  {
    System.out.println("Hello World");
  }
}  